<?php
	/*
		Cheryllynn Walsh
    	October 23, 2014
	*/
?>

<!doctype html>
<html>
<head>

<style>
body {background-color:lightgrey}
  h1   {color:Dark blue}
  p    {color:black}
</style>

<meta charset="utf-8">
<title>Cheryllynn's Yorkies</title>
<link href="common.php" rel="stylesheet" type="text/css" />
<link href="custom.php" rel="stylesheet" type="text/css" />
</head>
	<body id="homepage">
	<div id="pagewrap">
</header>
   <nav>
      <ul>
         <li><a id="homelink" href="Welcome.html">Home</a></li>
         <li><a id="memberloginlink" href="memberlogin.html">Member Login</a></li>
         <li><a id="sellindoglink" href="sellingdog.html">Selling Dog</a></li>
         <li><a id="buyingdoglink" href="buyingdog.html">Buying dog</a></li>
      </ul>
   </nav>
<body>

<?php
	// ECHO out a heading
             echo "<center><h1>Welcome!</h1></center>";
?>


<p><font size="5">Sale Yorkies</font></p>
<p><font size="5">Hi, My dogs are have two Yorkies and Biewer Yorkies. </br>
I have puppies, so I have AKC and CKC register. We are very beautiful kind special.</br>
If you sure want to dogs. Please call, text, or email.</br>
519-947-3481</br>
wffwff.hotmail.com
</font></p>

<br />
<center><img src="SA400778 - Copy.jpg" /></center>

</body>
</html>