<?php # Script 3.5 - Content Int.php
$page_title = 'Trip Cost Members';
include ('include/header.html');

<html>
<head>
<title>Yorkies and Biewer Yorkeis Puppies</title>

<h2 class="wsite-content-title" style="text-align:left;"><strong style="">Yorkies and Biewer Puppies</strong><br />
<strong style="">3512 Boggy Bayou Rd.&nbsp;</strong><br />
<strong style="">Jonesville, LA 71343&nbsp;</strong><br /><br />
<strong style="">(318) 386-6276</strong><br /><br /></h2>

<h2 class="wsite-content-title" style="text-align:left;">
Visit our Sister-Site: &nbsp; <a href="http://www.wffwff.com" target="_blank">Wffwff.com</a></h2></div>
</div>

?>

