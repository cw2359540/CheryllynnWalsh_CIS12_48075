<?php # Script 3.4 - index.php
$page_title 'Welcome to this Site!';
include ('includes/header.html');
?>

	<h1>Welcome!</h1>
	
	<p>This are two different dogs Yorkies and Biewer Yorkies.</p>
	
	<p>Welcome to My Yorkies and Biewer Yorkies. The home of some very spoiled baby Yorkies.  
	Specializing nation sizes different yorkies. "Yorkies are the perfect travel companion". 
	All Yorkie puppies are AKC and certified PEDIGREE they also come with: 
	health guarantee, health certificate from veterinarian, vaccines  and de-worming. 
	My Yorkie babies for sale, are precious! they have beautiful Yorkie coats and tiny faces, 
	small stand up ears. Just look at all my Yorkie pictures and you will see the quality. 
	Also they are very sweet + snuggly, Yorkies and parti Yorkies love a lap to be on.</p>

<br />
<center><img src="SA400778 - Copy.jpg" /></center>


<?php
include ('includes/footer.html');
?>
	